# TradeHub Complete Setup

This package connects TradeHub to your existing Supabase project and Paystack server APIs.

## 1. Supabase
Run `supabase-schema.sql` in Supabase SQL Editor. It creates/updates profiles, wallets, ledger, marketplace listings, orders and withdrawals, plus secure RPCs. Your existing legacy `social_media_listings` table is preserved.

## 2. GitHub/Vercel
Upload all files/folders in this ZIP to the root of the `Samuel-Adeniran/Tradehub` repository and commit. `index.html` is already connected to your Supabase project using the publishable key.

## 3. Vercel Environment Variables
Add these in Vercel → Settings → Environment Variables:
- `PAYSTACK_SECRET_KEY` = your Paystack secret key
- `SUPABASE_URL` = your Supabase project URL
- `SUPABASE_SERVICE_ROLE_KEY` = your Supabase service-role key
- `APP_URL` = your Vercel site URL, e.g. https://your-site.vercel.app

Never put Paystack secret or Supabase service-role keys in `index.html`, GitHub, or chat.

## 4. Paystack webhook
Set the Paystack webhook URL to:
`https://YOUR-VERCEL-DOMAIN/api/paystack/webhook`
Use Paystack TEST keys first.

## 5. Important
Wallet funding is confirmed by Paystack webhook and credited atomically. Marketplace orders reserve buyer wallet funds and put seller money into pending earnings until the buyer marks the order completed. Withdrawals reserve available earnings and create an admin-review request; automatic bank payout still requires Paystack transfer configuration/admin approval.
