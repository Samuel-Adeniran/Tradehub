# TradeHub Complete Package

This package restores a full TradeHub dashboard and marketplace foundation while keeping real wallet/payment flows server-side.

## 1. Supabase
Run `supabase-schema.sql` in Supabase SQL Editor.

Then replace in `index.html`:
- `YOUR_SUPABASE_URL`
- `YOUR_SUPABASE_PUBLISHABLE_KEY`

Use only the **publishable/anon** key in the browser. Never put the Supabase service-role key in HTML.

## 2. Vercel environment variables
Add:
- `SUPABASE_URL`
- `SUPABASE_SERVICE_ROLE_KEY`
- `PAYSTACK_SECRET_KEY`
- `APP_URL` (your Vercel site URL, e.g. https://your-site.vercel.app)

## 3. Paystack
Use TEST keys first. Configure the webhook URL:
`https://YOUR-VERCEL-DOMAIN/api/paystack/webhook`

Do not put the Paystack secret key in GitHub or `index.html`.

## 4. What is included
- Full responsive dashboard
- Wallet balance and transaction history
- Paystack wallet funding
- Marketplace categories: Gift Cards, Social Media, Digital Services, Gaming, Virtual Numbers
- Seller listing creation
- Wallet-funded orders
- Vendor earnings
- Withdrawal requests
- Supabase authentication
- RLS policies
- Server-side Paystack initialization/webhook verification

## 5. Important production note
This is a complete working marketplace foundation, but real-money public launch still requires operational setup: Paystack account approval, webhook testing, vendor verification/KYC where applicable, admin review tools, fulfilment/delivery flows, refunds/disputes, and final security testing. Never treat a frontend balance as proof of funds.
