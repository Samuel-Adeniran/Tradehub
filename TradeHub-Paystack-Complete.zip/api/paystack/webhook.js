const crypto=require('crypto');
module.exports=async(req,res)=>{
 if(req.method!=='POST')return res.status(405).end();
 try{
  const sig=req.headers['x-paystack-signature'];const raw=JSON.stringify(req.body);
  const expected=crypto.createHmac('sha512',process.env.PAYSTACK_SECRET_KEY).update(raw).digest('hex');
  if(!sig||!crypto.timingSafeEqual(Buffer.from(sig),Buffer.from(expected)))return res.status(401).end();
  if(req.body.event!=='charge.success')return res.status(200).end();
  const d=req.body.data;
  if(d.status!=='success'||d.currency!=='NGN')return res.status(200).end();
  const amount=Number(d.amount)/100;
  const h={apikey:process.env.SUPABASE_SERVICE_ROLE_KEY,Authorization:'Bearer '+process.env.SUPABASE_SERVICE_ROLE_KEY,'Content-Type':'application/json'};
  const r=await fetch(process.env.SUPABASE_URL+'/rest/v1/rpc/process_paystack_credit',{
    method:'POST',headers:h,body:JSON.stringify({p_reference:d.reference,p_amount:amount})
  });
  if(!r.ok)return res.status(500).end();
  res.status(200).end();
 }catch(e){console.error(e);res.status(500).end()}
};