module.exports=async(req,res)=>{if(req.method!=='POST')return res.status(405).json({error:'Method not allowed'});try{
const ref=req.body?.reference;if(!ref)return res.status(400).json({error:'Missing reference'});
const r=await fetch('https://api.paystack.co/transaction/verify/'+encodeURIComponent(ref),{headers:{Authorization:'Bearer '+process.env.PAYSTACK_SECRET_KEY}});
const d=await r.json();if(!r.ok||!d.status)return res.status(400).json({error:d.message||'Verification failed'});
res.json({status:d.data.status,amount:Number(d.data.amount)/100,reference:d.data.reference});
}catch(e){res.status(500).json({error:e.message||'Server error'})}};