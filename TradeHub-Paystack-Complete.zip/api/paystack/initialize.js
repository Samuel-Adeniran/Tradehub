async function getUser(req){const a=req.headers.authorization||'';if(!a.startsWith('Bearer '))return null;const r=await fetch(process.env.SUPABASE_URL+'/auth/v1/user',{headers:{apikey:process.env.SUPABASE_SERVICE_ROLE_KEY,Authorization:a}});return r.ok?await r.json():null}
module.exports=async(req,res)=>{if(req.method!=='POST')return res.status(405).json({error:'Method not allowed'});try{
const u=await getUser(req);if(!u?.id)return res.status(401).json({error:'Please sign in first.'});
const amount=Number(req.body?.amount);if(!Number.isFinite(amount)||amount<100)return res.status(400).json({error:'Minimum funding is ₦100.'});
const reference='TH-'+Date.now()+'-'+Math.random().toString(36).slice(2,9);
const h={apikey:process.env.SUPABASE_SERVICE_ROLE_KEY,Authorization:'Bearer '+process.env.SUPABASE_SERVICE_ROLE_KEY,'Content-Type':'application/json',Prefer:'return=minimal'};
let x=await fetch(process.env.SUPABASE_URL+'/rest/v1/wallet_transactions',{method:'POST',headers:h,body:JSON.stringify({user_id:u.id,type:'credit',amount,reference,description:'Paystack wallet funding',status:'pending'})});
if(!x.ok)throw Error('Could not create payment record.');
x=await fetch('https://api.paystack.co/transaction/initialize',{method:'POST',headers:{Authorization:'Bearer '+process.env.PAYSTACK_SECRET_KEY,'Content-Type':'application/json'},body:JSON.stringify({email:u.email,amount:String(Math.round(amount*100)),currency:'NGN',reference,callback_url:(process.env.APP_URL||'https://example.com')+'/?payment=return&reference='+encodeURIComponent(reference)})});
const d=await x.json();if(!x.ok||!d.status)throw Error(d.message||'Paystack initialization failed.');
res.json({authorization_url:d.data.authorization_url,reference:d.data.reference});
}catch(e){res.status(500).json({error:e.message||'Server error'})}};