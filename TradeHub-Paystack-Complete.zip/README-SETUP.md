# TradeHub + Paystack

This package adds the real foundation: Supabase login, wallet, Paystack funding, payment webhook, wallet ledger, marketplace listings and wallet-funded orders.

1. Run `supabase-schema.sql` in your Supabase SQL Editor.
2. In `index.html`, replace `YOUR_SUPABASE_URL` and `YOUR_SUPABASE_PUBLISHABLE_KEY`.
3. In Vercel Environment Variables add:
   PAYSTACK_SECRET_KEY
   SUPABASE_URL
   SUPABASE_SERVICE_ROLE_KEY
   APP_URL
4. Set Paystack webhook to:
   https://YOUR-VERCEL-DOMAIN/api/paystack/webhook
5. Use Paystack TEST keys first.
6. Never put PAYSTACK_SECRET_KEY or SUPABASE_SERVICE_ROLE_KEY in HTML or GitHub.

The withdrawal table is included, but automatic vendor payouts need the next server-side transfer module and Paystack transfer setup. Do not launch real-money marketplace payouts until that is configured and tested.
