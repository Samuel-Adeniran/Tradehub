create extension if not exists pgcrypto;
create table if not exists public.profiles(id uuid primary key references auth.users(id) on delete cascade,email text,role text default 'customer',created_at timestamptz default now());
create table if not exists public.wallets(user_id uuid primary key references auth.users(id) on delete cascade,balance numeric(14,2) not null default 0,updated_at timestamptz default now());
create table if not exists public.wallet_transactions(id uuid primary key default gen_random_uuid(),user_id uuid not null references auth.users(id) on delete cascade,type text not null,amount numeric(14,2) not null,reference text unique,description text,status text default 'pending',created_at timestamptz default now());
create table if not exists public.social_media_listings(id uuid primary key default gen_random_uuid(),user_id uuid references auth.users(id) on delete set null,service_name text not null,platform text not null,service_type text not null,price numeric(14,2) not null,description text not null,status text default 'active',created_at timestamptz default now());
create table if not exists public.orders(id uuid primary key default gen_random_uuid(),buyer_id uuid references auth.users(id) on delete cascade,vendor_id uuid references auth.users(id) on delete set null,listing_id uuid references public.social_media_listings(id),amount numeric(14,2) not null,status text default 'paid',created_at timestamptz default now());
create table if not exists public.withdrawal_requests(id uuid primary key default gen_random_uuid(),user_id uuid references auth.users(id) on delete cascade,amount numeric(14,2) not null,bank_code text,account_number text,account_name text,status text default 'pending',paystack_reference text,created_at timestamptz default now());

create or replace function public.new_user() returns trigger language plpgsql security definer set search_path=public as $$ begin
insert into public.profiles(id,email) values(new.id,new.email) on conflict do nothing;
insert into public.wallets(user_id) values(new.id) on conflict do nothing; return new; end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.new_user();

alter table public.profiles enable row level security; alter table public.wallets enable row level security; alter table public.wallet_transactions enable row level security; alter table public.social_media_listings enable row level security; alter table public.orders enable row level security; alter table public.withdrawal_requests enable row level security;
create policy if not exists "profile own" on public.profiles for select to authenticated using(id=auth.uid());
create policy if not exists "wallet own" on public.wallets for select to authenticated using(user_id=auth.uid());
create policy if not exists "ledger own" on public.wallet_transactions for select to authenticated using(user_id=auth.uid());
create policy if not exists "listing read" on public.social_media_listings for select to anon,authenticated using(status='active');
create policy if not exists "listing own insert" on public.social_media_listings for insert to authenticated with check(user_id=auth.uid());
create policy if not exists "orders own" on public.orders for select to authenticated using(buyer_id=auth.uid());
create policy if not exists "withdraw own" on public.withdrawal_requests for select to authenticated using(user_id=auth.uid());

create or replace function public.credit_wallet(p_user_id uuid,p_amount numeric) returns boolean language plpgsql security definer set search_path=public as $$ begin update public.wallets set balance=balance+p_amount,updated_at=now() where user_id=p_user_id; return found; end; $$;
create or replace function public.create_order(p_buyer_id uuid,p_listing_id uuid) returns uuid language plpgsql security definer set search_path=public as $$
declare l public.social_media_listings; oid uuid;
begin select * into l from public.social_media_listings where id=p_listing_id and status='active' for update;
if not found then raise exception 'Listing unavailable'; end if;
if l.user_id=p_buyer_id then raise exception 'You cannot buy your own listing'; end if;
update public.wallets set balance=balance-l.price,updated_at=now() where user_id=p_buyer_id and balance>=l.price;
if not found then raise exception 'Insufficient wallet balance'; end if;
insert into public.wallet_transactions(user_id,type,amount,reference,description,status) values(p_buyer_id,'debit',l.price,'ORDER-'||gen_random_uuid()::text,'Marketplace purchase','completed');
insert into public.orders(buyer_id,vendor_id,listing_id,amount,status) values(p_buyer_id,l.user_id,l.id,l.price,'paid') returning id into oid; return oid;
end; $$;
revoke all on function public.credit_wallet(uuid,numeric) from public,anon,authenticated;
revoke all on function public.create_order(uuid,uuid) from public,anon,authenticated;
grant execute on function public.credit_wallet(uuid,numeric) to service_role;
grant execute on function public.create_order(uuid,uuid) to service_role;
